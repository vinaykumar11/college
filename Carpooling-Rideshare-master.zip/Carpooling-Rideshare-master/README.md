# Carpooling-Rideshare
The application will Create/Read/Update/Delete trip posts shared between all users in real time. There will be one public shared wall (for all posted trips) for all users. So users will read all previously submitted trips by all other users
